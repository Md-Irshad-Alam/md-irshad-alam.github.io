import React from 'react'
import { Button } from '@mui/material';
import style from './Resume.css'
import Home from '../Home/Home';

import RemoveRedEyeIcon from '@mui/icons-material/RemoveRedEye';

function Resume() {
  const handleDownload = () => {
    const link = document.createElement('a');
    link.download = 'resume.pdf';
    link.href = './Irshad_resume.pdf';
    link.click();
  };

  return (
    <div className='resume_container'>
      <RemoveRedEyeIcon/>
       <button id="resume-button-1" onClick={handleOpen}>Resume </button>
    
     </div>
  );
}

export default Resume
